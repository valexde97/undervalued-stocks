// /api/llm/commentary.ts
export const runtime = "nodejs";
import { llmCommentary } from "../../handlers/llm/_handlers/llmCommentary";
export default llmCommentary;
